const { getDefaultConfig } = require("expo/metro-config");
const path = require("path");

const config = getDefaultConfig(__dirname);

// The app imports the generated API client as "@workspace/api-client-react".
// In the Replit monorepo that is a pnpm workspace package; in this standalone
// package it is vendored under ./vendor. We resolve it explicitly here (and via
// tsconfig "paths" for typechecking) so Metro bundles the vendored source.
// We chain to Expo's existing resolveRequest so tsconfig "@/" paths and package
// exports keep working.
const aliases = {
  "@workspace/api-client-react": path.resolve(
    __dirname,
    "vendor/api-client-react/src/index.ts",
  ),
};

const defaultResolveRequest = config.resolver.resolveRequest;
config.resolver.resolveRequest = (context, moduleName, platform) => {
  const target = aliases[moduleName];
  if (target) {
    return { type: "sourceFile", filePath: target };
  }
  if (defaultResolveRequest) {
    return defaultResolveRequest(context, moduleName, platform);
  }
  return context.resolveRequest(context, moduleName, platform);
};

module.exports = config;
