import { useSignIn, useSSO } from "@clerk/expo";
import { FontAwesome } from "@expo/vector-icons";
import * as AuthSession from "expo-auth-session";
import { type Href, Link, useRouter } from "expo-router";
import * as WebBrowser from "expo-web-browser";
import React, { useCallback, useEffect, useState } from "react";
import { Platform, View } from "react-native";

import { AuthDivider, AuthShell } from "@/components/auth-ui";
import { Button, TextField, ThemedText } from "@/components/ui";
import { useColors } from "@/hooks/useColors";
import { useI18n } from "@/lib/i18n";

// Preload the in-app browser on Android to reduce OAuth latency.
export const useWarmUpBrowser = () => {
  useEffect(() => {
    if (Platform.OS !== "android") return;
    void WebBrowser.warmUpAsync();
    return () => {
      void WebBrowser.coolDownAsync();
    };
  }, []);
};

WebBrowser.maybeCompleteAuthSession();

type NavigateArgs = {
  session?: { currentTask?: unknown } | null;
  decorateUrl: (url: string) => string;
};

export default function SignInScreen() {
  useWarmUpBrowser();
  const { signIn, errors, fetchStatus } = useSignIn();
  const { startSSOFlow } = useSSO();
  const { t } = useI18n();
  const c = useColors();
  const router = useRouter();

  const [emailAddress, setEmailAddress] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  const navigate = useCallback(
    ({ session, decorateUrl }: NavigateArgs) => {
      if (session?.currentTask) return;
      const url = decorateUrl("/");
      if (typeof url === "string" && url.startsWith("http")) {
        if (typeof window !== "undefined") window.location.href = url;
      } else {
        router.replace(url as Href);
      }
    },
    [router],
  );

  const onSubmit = useCallback(async () => {
    setFormError(null);
    const { error } = await signIn.password({ emailAddress, password });
    if (error) return;

    if (signIn.status === "complete") {
      await signIn.finalize({ navigate });
    } else if (signIn.status === "needs_client_trust") {
      const factor = signIn.supportedSecondFactors?.find(
        (f) => f.strategy === "email_code",
      );
      if (factor) await signIn.mfa.sendEmailCode();
    } else {
      // Unhandled status (e.g. second factor / new password required) — never
      // silently dead-end; surface a generic, actionable error.
      setFormError(t("auth.error"));
    }
  }, [signIn, emailAddress, password, navigate, t]);

  const onVerify = useCallback(async () => {
    await signIn.mfa.verifyEmailCode({ code });
    if (signIn.status === "complete") {
      await signIn.finalize({ navigate });
    }
  }, [signIn, code, navigate]);

  const onGoogle = useCallback(async () => {
    try {
      const { createdSessionId, setActive } = await startSSOFlow({
        strategy: "oauth_google",
        redirectUrl: AuthSession.makeRedirectUri(),
      });
      if (createdSessionId && setActive) {
        await setActive({ session: createdSessionId, navigate });
      }
    } catch (err) {
      console.error(JSON.stringify(err, null, 2));
    }
  }, [startSSOFlow, navigate]);

  const busy = fetchStatus === "fetching";

  // New-device verification (Clerk client trust) — collect the emailed code.
  if (signIn.status === "needs_client_trust") {
    return (
      <AuthShell title={t("auth.verifyTitle")} subtitle={t("auth.verifyDesc")}>
        <TextField
          label={t("auth.codeLabel")}
          value={code}
          onChangeText={setCode}
          placeholder={t("auth.codePlaceholder")}
          keyboardType="number-pad"
          error={errors?.fields?.code?.message}
        />
        <Button
          label={t("auth.verify")}
          onPress={onVerify}
          loading={busy}
          disabled={!code}
        />
        <View style={{ marginTop: 12 }}>
          <Button
            label={t("auth.resend")}
            variant="ghost"
            onPress={() => signIn.mfa.sendEmailCode()}
          />
        </View>
      </AuthShell>
    );
  }

  return (
    <AuthShell title={t("auth.signInTitle")} subtitle={t("auth.signInSubtitle")}>
      <Button
        label={t("auth.google")}
        variant="outline"
        onPress={onGoogle}
        icon={<FontAwesome name="google" size={16} color={c.foreground} />}
      />
      <AuthDivider label={t("auth.or")} />
      {formError ? (
        <ThemedText
          size={13}
          color={c.destructive}
          center
          style={{ marginBottom: 10 }}
        >
          {formError}
        </ThemedText>
      ) : null}
      <TextField
        label={t("auth.email")}
        value={emailAddress}
        onChangeText={setEmailAddress}
        placeholder={t("auth.emailPlaceholder")}
        keyboardType="email-address"
        autoCapitalize="none"
        autoComplete="email"
        error={errors?.fields?.identifier?.message}
      />
      <TextField
        label={t("auth.password")}
        value={password}
        onChangeText={setPassword}
        placeholder={t("auth.passwordPlaceholder")}
        secureTextEntry
        autoComplete="password"
        error={errors?.fields?.password?.message}
      />
      <Button
        label={t("auth.continue")}
        onPress={onSubmit}
        loading={busy}
        disabled={!emailAddress || !password}
      />
      <View
        style={{
          flexDirection: "row",
          justifyContent: "center",
          gap: 6,
          marginTop: 18,
          flexWrap: "wrap",
        }}
      >
        <ThemedText muted size={14}>
          {t("auth.noAccount")}
        </ThemedText>
        <Link href="/(auth)/sign-up" replace>
          <ThemedText gold size={14} weight="bold">
            {t("auth.signUpLink")}
          </ThemedText>
        </Link>
      </View>
    </AuthShell>
  );
}
