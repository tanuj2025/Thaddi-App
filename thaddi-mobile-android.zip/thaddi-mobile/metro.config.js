const { getDefaultConfig } = require("expo/metro-config");
const path = require("path");

const config = getDefaultConfig(__dirname);

// The mobile app used to consume the API client as a pnpm-workspace package
// (`@workspace/api-client-react`). In this standalone export the client source
// is vendored under `vendor/api-client-react`; alias the bare specifier to it so
// every existing import keeps working unchanged.
const ALIASES = {
  "@workspace/api-client-react": path.resolve(
    __dirname,
    "vendor/api-client-react/src/index.ts",
  ),
};

config.resolver.resolveRequest = (context, moduleName, platform) => {
  const aliased = ALIASES[moduleName];
  if (aliased) {
    return { type: "sourceFile", filePath: aliased };
  }
  return context.resolveRequest(context, moduleName, platform);
};

module.exports = config;
