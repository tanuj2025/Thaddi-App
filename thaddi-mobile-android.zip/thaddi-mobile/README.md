# THADDI — Standalone Android build

This is a self-contained copy of the THADDI mobile app, ready to be built into an
**installable Android APK** using Expo's free cloud build service (EAS Build).

It talks to the **same production backend as the live app** (`https://thaddi.app`),
so accounts, challenges, and data are shared with the published web/iOS apps. This
package is independent of the Replit monorepo — the shared API client has been
vendored in (`vendor/api-client-react`), so nothing else is required.

---

## What you need

1. A computer with **Node.js 18 or newer** (Windows, macOS, or Linux — a Mac is
   NOT required for Android).
2. A **free Expo account** — sign up at https://expo.dev.
3. Your **Clerk publishable key** (used for sign-in). It is a public value that
   starts with `pk_live_…`. Find it in your Clerk dashboard under
   **API keys → Publishable key** (the same key your website uses).

---

## Step-by-step

From a terminal, inside this folder:

### 1. Install dependencies
```bash
npm install
```

### 2. Add your Clerk publishable key
Open **`eas.json`** and replace `PASTE_YOUR_CLERK_PUBLISHABLE_KEY_HERE` (under the
`preview` profile) with your real `pk_live_…` key. Without this, sign-in will not
work in the built app.

### 3. Install the EAS command-line tool
```bash
npm install -g eas-cli
```

### 4. Sign in to Expo
```bash
eas login
```

### 5. Link this project to your Expo account
```bash
eas init
```
Accept the defaults when prompted. This creates the project on your Expo account
and writes the project id into `app.json`.

### 6. Build the APK
```bash
eas build --platform android --profile preview
```
The build runs on Expo's servers (the first one can take ~10–20 minutes). When it
finishes, the terminal prints a **download link** and a QR code.

### 7. Install on your Android device
Open the download link on your Android phone, download the `.apk`, and tap to
install. You may need to allow **"Install unknown apps"** for your browser the
first time. (Or scan the QR code shown after the build.)

---

## Notes

- **Sign in with Apple** is iOS-only and is hidden on Android — Google and
  email/password sign-in work normally.
- **In-app purchases (the paywall)** require the app to be distributed through the
  Google Play Store, so they will not complete on a directly-installed APK. The
  rest of the app works normally. To enable purchases later, fill in
  `EXPO_PUBLIC_REVENUECAT_ANDROID_API_KEY` in `eas.json` and distribute via Play
  Store internal testing.
- To later publish to the **Google Play Store**, build with the `production`
  profile (`eas build --platform android --profile production`) — it produces an
  `.aab` app bundle for the Play Console.

### Optional: initialize git first
EAS works best inside a git repository. If you see a git-related warning, run this
once before step 6:
```bash
git init && git add -A && git commit -m "thaddi mobile"
```
